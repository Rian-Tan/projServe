//
//  ViewController.swift
//  DocControl
//
//  Created by CHONG YUE HANG stu on 7/9/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

